
import {useState} from 'react';
export default function App(){
const [page,setPage]=useState('employee');
return <div style={{fontFamily:'Arial',display:'flex'}}>
<div style={{width:220,padding:20,background:'#1e293b',color:'white',height:'100vh'}}>
<h2>HRMS</h2>
<button onClick={()=>setPage('employee')}>Employee</button><br/><br/>
<button onClick={()=>setPage('hr')}>HR</button><br/><br/>
<button onClick={()=>setPage('manager')}>Manager</button><br/><br/>
<button onClick={()=>setPage('policy')}>Policy</button>
</div>
<div style={{padding:20,flex:1}}>
{page==='employee'&&<div><h1>Employee Dashboard</h1><p>Attendance, leave balance, profile.</p></div>}
{page==='hr'&&<div><h1>HR Dashboard</h1><p>Leave approvals and attendance records.</p></div>}
{page==='manager'&&<div><h1>Manager Dashboard</h1><p>Team analytics and overtime monitoring.</p></div>}
{page==='policy'&&<div><h1>Policy Engine</h1><textarea rows='10' cols='60' defaultValue='{"minimum_work_hours":8,"late_after":"09:30"}'></textarea></div>}
</div></div>
}
